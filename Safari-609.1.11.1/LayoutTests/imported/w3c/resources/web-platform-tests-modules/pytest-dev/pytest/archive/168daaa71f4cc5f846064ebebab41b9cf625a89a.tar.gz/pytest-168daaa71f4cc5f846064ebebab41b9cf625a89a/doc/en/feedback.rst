
What users say:

    `py.test is pretty much the best thing ever`_ (Alex Gaynor)


.. _`py.test is pretty much the best thing ever`_ (Alex Gaynor)
    http://twitter.com/#!/alex_gaynor/status/22389410366
