
def test_quick(setup):
    pass
