def main(request, response):
    response.headers.set("Content-Type", "text/plain")
    return "PASS"
