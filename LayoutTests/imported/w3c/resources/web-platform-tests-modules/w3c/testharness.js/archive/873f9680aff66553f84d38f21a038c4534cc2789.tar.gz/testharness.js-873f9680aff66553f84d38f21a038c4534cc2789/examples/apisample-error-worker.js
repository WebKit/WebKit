importScripts("../testharness.js");

throw new Error("This failure is expected.");
